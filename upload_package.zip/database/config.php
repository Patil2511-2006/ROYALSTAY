<?php

$conn = mysqli_connect("localhost","root","","hotel_db",3307);

if(!$conn){
    die("Database Connection Failed: " . mysqli_connect_error());
}

?>